package com.example.httpproxy;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        statusText = new TextView(this);
        statusText.setText("Starting HTTP Proxy...");
        setContentView(statusText);

        new Thread(() -> {
            String ipList = getLocalIpAddresses();
            runOnUiThread(() -> statusText.setText("Proxy running on:\n" + ipList));
            startProxy();
        }).start();
    }

    private String getLocalIpAddresses() {
        StringBuilder ipInfo = new StringBuilder();
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        ipInfo.append(inetAddress.getHostAddress()).append(":8080\n");
                    }
                }
            }
        } catch (SocketException ex) {
            ipInfo.append("Error fetching IPs: ").append(ex.getMessage());
        }
        return ipInfo.toString();
    }

    private void startProxy() {
        try {
            ServerSocket serverSocket = new ServerSocket(8080);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleClient(Socket clientSocket) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            OutputStream out = clientSocket.getOutputStream();

            String requestLine = in.readLine();
            if (requestLine == null || !requestLine.startsWith("GET")) {
                clientSocket.close();
                return;
            }

            String[] parts = requestLine.split(" ");
            URL url = new URL(parts[1]);

            Socket remoteSocket = new Socket(url.getHost(), url.getPort() == -1 ? 80 : url.getPort());
            PrintWriter remoteOut = new PrintWriter(remoteSocket.getOutputStream());
            remoteOut.println(requestLine);
            String line;
            while (!(line = in.readLine()).isEmpty()) {
                remoteOut.println(line);
            }
            remoteOut.println();
            remoteOut.flush();

            InputStream remoteIn = remoteSocket.getInputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = remoteIn.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }

            out.flush();
            remoteSocket.close();
            clientSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
